import React, { Component } from 'react';
import {connect} from 'react-redux';
import {sendMessage} from './chat';
import './App.css';
import * as ReactDOM from 'react-dom';
import bot from './new-bot.png';
import { library } from '@fortawesome/fontawesome-svg-core';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRobot, faUserTie, faMinus, faPlus, faRedo, faTimes, faComments } from '@fortawesome/free-solid-svg-icons';

library.add(faUserTie)
library.add(faRobot)
library.add(faMinus)
library.add(faPlus)
library.add(faRedo)
library.add(faTimes)
library.add(faComments)

const spinnerStyle = {
  hidden: true
};

class App extends Component {
  
  render() {
    const {feed, sendMessage} = this.props;
    return (
      <div className="fullDiv">
        <div className="headingDiv"></div>
        <div className="firstParagraph"></div>
        <div className="subParagraph1"></div>
        <div className="subParagraph2"></div>
        <div className="subParagraph3"></div>
        <div className="subParagraph4"></div>
        <div className="subParagraph5"></div>
        <div className="subParagraph6"></div>
        <div className="footerDiv"></div>
      <div id="chatDivFade" className="chatDiv animated">
        <div className="botImage"><img src={bot} alt="Logo"/></div>
        <h4 className="chatHeading">
          <div className="chatHeadingText">D Operate
            <FontAwesomeIcon className="icon-redo" icon="redo"
              />
            <FontAwesomeIcon id="icon-times" size = "1x"
              className="icon-times" icon="times" onClick={this.onItemClick}/>
          </div>
        </h4>
        <div ref="chatList" className="chatBox">
          <ul className="ulWOBullet">
            {feed.map(entry => 
                    <li className={"message " + (entry.sender === 'bot' ? 'to' : 'from')} 
                        id="entry.text">
                        <div className="actualData" display="block">
                          <div>
                            {entry.text}
                          </div>
                          {/* <div > {new Date().getDate() + '/' + new Date().getMonth() + 1 + '/' + new Date().getFullYear()
           + ' ' + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds()} </div> */}
                          <div className={(entry.sender === 'bot' ? 'emoji-bot' : 'emoji-user')}>
                            <FontAwesomeIcon icon={(entry.sender === 'bot' ? 'robot' : 'user-tie')} 
                            size="1x" color={(entry.sender === 'bot' ? '#2095FE' : '#2095FE')}/>
                          </div>
                        </div>
                    </li>     
            )}
                    <li>
                      <div className="spinner message" style={spinnerStyle}>
                        <div className="bounce1"></div>
                        <div className="bounce2"></div>
                        <div className="bounce3"></div>
                      </div>
                    </li>
          </ul>
        </div>
        <input id="textInput" className="textBox" type="text" placeholder="Please type your message here" 
              onKeyDown={(e) => e.keyCode === 13 ? sendMessage(e.target.value) : null}></input>
        {/* <p className="sessionMsg">***The session will reset after 2 minutes of user being inactive</p> */}
      </div>
      <FontAwesomeIcon id="icon-comments" size="3x" className="icon-comments" icon="comments" 
        onClick={this.onChatClick}/>
      </div>
    );
  }

  onItemClick(event) {
    //console.log("am here");
    var el = document.getElementById("chatDivFade");
    el.classList.add("fadeOutRight");
    el.classList.remove("fadeInRight");
  }

  onChatClick(event) {
    //console.log("am here");
    var el = document.getElementById("chatDivFade");
    el.classList.add("fadeInRight");
    el.classList.remove("fadeOutRight");
  }

  getCurrentDate(){
    var date = new Date().getDate(); //Current Date
    var month = new Date().getMonth() + 1; //Current Month
    var year = new Date().getFullYear(); //Current Year
    var hours = new Date().getHours(); //Current Hours
    var min = new Date().getMinutes(); //Current Minutes
    var sec = new Date().getSeconds(); //Current Seconds
    return new Date().getDate() + '/' + new Date().getMonth() + 1 + '/' + new Date().getFullYear()
           + ' ' + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
  }

  componentDidMount() {
    document.getElementsByClassName("spinner")[0].hidden = true;
    this.clearForm();
  }

  clearForm = () => {
    document.getElementsByClassName('textBox').value = '';
  }

  componentDidUpdate(){
    this.scrollToBottom();
  }

  scrollToBottom = () => {
    const { chatList } = this.refs;
    const scrollHeight = chatList.scrollHeight;
    const height = chatList.clientHeight;
    const maxScrollTop = scrollHeight - height;
    ReactDOM.findDOMNode(chatList).scrollTop = maxScrollTop > 0 ? maxScrollTop : 0;
  }
}

const mapStateToProps = state => ({
  feed: state
});

export default connect(mapStateToProps,{sendMessage})(App);
