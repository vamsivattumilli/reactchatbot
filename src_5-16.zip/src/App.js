import React, { Component } from 'react';
import {connect} from 'react-redux';
import {sendMessage} from './chat';
import './App.css';
import './font-awesome-animation.min.css';
import * as ReactDOM from 'react-dom';
import bot from './new-bot-black.png';
import yellowBot from './new-bot-black-yellow.png';
import { library } from '@fortawesome/fontawesome-svg-core';
import nl2br from 'react-newline-to-break';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRobot, faUserTie, faMinus, faPlus, faRedo, faTimes, faComments } from '@fortawesome/free-solid-svg-icons';

library.add(faUserTie)
library.add(faRobot)
library.add(faMinus)
library.add(faPlus)
library.add(faRedo)
library.add(faTimes)
library.add(faComments)

const spinnerStyle = {
  hidden: true
};

class App extends Component {
  
  render() {
    const {feed, sendMessage} = this.props;
    return (
      <div className="fullDiv">
        <div className="headingDiv"></div>
        <div className="firstParagraph"></div>
        <div className="subParagraph1"></div>
        <div className="subParagraph2"></div>
        <div className="subParagraph3"></div>
        <div className="subParagraph4"></div>
        <div className="subParagraph5"></div>
        <div className="subParagraph6"></div>
        <div className="footerDiv"></div>
      <div id="chatDivFade" className="chatDiv animated fadeOutRight">
        <div className="botImage"><img src={bot} alt="Logo"/>
        <img src={yellowBot} hidden="true" alt="Logo"/></div>
        <h4 className="chatHeading">
          <div className="chatHeadingText">D Operate
            <FontAwesomeIcon id="icon-times" size = "1x"
              className="icon-times" icon="times" onClick={this.onItemClick}/>
          </div>
        </h4>
        <div ref="chatList" className="chatBox">
          <ul className="ulWOBullet">
            {feed.map(entry => 
                    <li className={"message " + (entry.sender === 'bot' ? 'to' : 'from')} 
                        id="entry.text">
                        <div className="actualData" display="block">
                          <div>
                            {nl2br(entry.text)}
                          </div>
                          {/* For more animations refer https://l-lin.github.io/font-awesome-animation/ */}
                          <div className={(entry.sender === 'bot' ? 'emoji-bot' : 'emoji-user')}>
                            <FontAwesomeIcon icon={(entry.sender === 'bot' ? 'robot' : 'user-tie')} 
                            size="1x" color={(entry.sender === 'bot' ? 'black' : 'black')}/>
                          </div>
                        </div>
                    </li>     
            )}
                    <li>
                      <div className="spinner message" style={spinnerStyle}>
                        <div className="bounce1"></div>
                        <div className="bounce2"></div>
                        <div className="bounce3"></div>
                      </div>
                    </li>
          </ul>
        </div>
        <input id="textInput" className="textBox" type="text" placeholder="Please type your message here" 
              onKeyDown={(e) => e.keyCode === 13 ? sendMessage(e.target.value) : null}></input>
      </div>
      {/* <FontAwesomeIcon id="icon-comments" size="3x" className="icon-comments" icon="comments" 
        onClick={this.onChatClick}/> */}
        <img id="iChat" className="icon-chat animated faa-tada" src={bot} 
              onClick={this.onChatClick} 
              />
        
      </div>
    );
  }

  onItemClick(event) {
    var el = document.getElementById("chatDivFade");
    el.classList.add("fadeOutRight");
    el.classList.remove("fadeInRight");
    var el2 = document.getElementById("iChat");
    el2.classList.add("faa-tada");
  }

  onChatClick(event) {
    var el = document.getElementById("chatDivFade");
    el.classList.add("fadeInRight");
    el.classList.remove("fadeOutRight");
    var el1 = document.getElementById("iChat");
    el1.classList.remove("faa-tada");
  }

  getCurrentDate(){
    var date = new Date().getDate(); //Current Date
    var month = new Date().getMonth() + 1; //Current Month
    var year = new Date().getFullYear(); //Current Year
    var hours = new Date().getHours(); //Current Hours
    var min = new Date().getMinutes(); //Current Minutes
    var sec = new Date().getSeconds(); //Current Seconds
    return new Date().getDate() + '/' + new Date().getMonth() + 1 + '/' + new Date().getFullYear()
           + ' ' + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
  }

  componentDidMount() {
    document.getElementsByClassName("spinner")[0].hidden = true;
    this.clearForm();
  }

  clearForm = () => {
    document.getElementsByClassName('textBox').value = '';
  }

  componentDidUpdate(){
    this.scrollToBottom();
  }

  scrollToBottom = () => {
    const { chatList } = this.refs;
    const scrollHeight = chatList.scrollHeight;
    const height = chatList.clientHeight;
    const maxScrollTop = scrollHeight - height;
    ReactDOM.findDOMNode(chatList).scrollTop = maxScrollTop > 0 ? maxScrollTop : 0;
  }
}

const mapStateToProps = state => ({
  feed: state
});

export default connect(mapStateToProps,{sendMessage})(App);
