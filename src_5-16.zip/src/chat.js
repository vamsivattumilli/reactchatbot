import { createStore, applyMiddleware } from 'redux';

const ON_MESSAGE = 'ON_MESSAGE';
const ON_RESET = "RESET";

export const sendMessage = (text, sender='user') => ({
    type: ON_MESSAGE,
    payload: {text, sender} 
});

export const resetSession = (text, sender='bot') => ({
    type: ON_RESET,
    payload: {text, sender} 
})

const messageMiddleware = () => next => action => {
    document.getElementById("textInput").value = '';
    document.getElementsByClassName("spinner")[0].hidden = false;
    next(action);
    
    if(action.type === ON_MESSAGE){
        const {text} = action.payload;
        let wasServerTimeout = true;
        let wasCallTimeOut = true;
        const timeout = setTimeout(() => {
            if(wasServerTimeout){
                document.getElementsByClassName("spinner")[0].hidden = true;
                next(resetSession("Session timed out", 'bot'));
            }
        } , 2*60*1000)

        const callTimeOut = setTimeout(() => {
            if(wasCallTimeOut){
                document.getElementsByClassName("spinner")[0].hidden = true;
                //wasServerTimeout = false;
                next(sendMessage("Apologies for the inconvinience, looks like the system is currently down. Please try again later", 'bot'));
            }
        } , 10000)
        
        fetch('http://127.0.0.1:5023/process?msg='+text, {
            method: 'POST',
            mode: 'cors',
            dataType: 'json',
            timeout: 2000
        }).then(results => {
            return results.clone().json()
        }).then(data => {
            let message = data.message;
            // if(message)
            setTimeout(function() { //Start the timer
                wasServerTimeout = false;
                wasCallTimeOut = false;
                document.getElementsByClassName("spinner")[0].hidden = true;
                next(sendMessage(message, 'bot')); //After 200ms, set render to true
            }.bind(this), 1000)
            //next(sendMessage(message, 'bot'));
        })
    }
}

const initState = [{text: 'Welcome User,\n I am your IT virtual assistant for all your support needs.'
                    , sender: 'bot'}];

const messageReducer = (state=initState, action) => {
    switch(action.type){
        case ON_MESSAGE:
            return [...state, action.payload]
        case ON_RESET:
            return initState;
        default:
            return state;
    }
}

export const store = createStore(messageReducer, applyMiddleware(messageMiddleware));